# TODO
1. Aggiustare la documentazione e fare le due versioni IT - EN
2. Aggiungere la classe '.rotation' e il keyframe
    - Aggiornare file e documentazione
3. Completare e aggiustare il codice della demo
4. Fare il css minificato
